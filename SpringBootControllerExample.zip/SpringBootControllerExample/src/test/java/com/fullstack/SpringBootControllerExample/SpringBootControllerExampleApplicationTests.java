package com.fullstack.SpringBootControllerExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootControllerExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
